#include <vector>
#include <iostream>
#include "header.h"

using namespace std;

int totalNode = 0;
int solutionCount = 0;

int colors[] = { BLUE, GREEN, RED, WHITE, YELLOW };
int nationalities[] = { BRIT, DANE, GERMAN, NORWEIGIAN, SWEDE };
int beverages[] = { BEER, COFFEE, MILK, TEA, WATER };
int cigars[] = { BLUE_MASTER, DUNHILL, PALL_MALL, PRINCE, BLEND };
int pets[] = { CAT, BIRD, DOG, ZEBRA, HORSE };

int usedColor[] = { 0,0,0,0,0 };
int usedNationality[] = { 0,0,0,0,0 };
int usedBeverage[] = { 0,0,0,0,0 };
int usedBrand[] = { 0,0,0,0,0 };
int usedPet[] = { 0,0,0,0,0 };

vector<int> solution;

void expand(int index) {
	if (index == 25) {
		printSolution();
		return;
	}

	if (index > 0 && index % 5 == 0) {
		if (promising(index) == -1) {
			return;
		}
	}
	totalNode++;

	switch (index%5)
	{
	case 0:
		for (int i = 0; i < 5; i++) {
			if (usedColor[i] == 1)
				continue;
			else {
				usedColor[i] = 1;
				solution.push_back(colors[i]);
				expand(index + 1);
				solution.pop_back();
				usedColor[i] = 0;
			}
		}
		break;
	case 1:
		for (int i = 0; i < 5; i++) {
			if (usedNationality[i] == 1)
				continue;
			else {
				usedNationality[i] = 1;
				solution.push_back(nationalities[i]);
				expand(index + 1);
				solution.pop_back();
				usedNationality[i] = 0;
			}
		}
		break;
	case 2: 
		for (int i = 0; i < 5; i++) {
			if (usedBeverage[i] == 1)
				continue;
			else {
				usedBeverage[i] = 1;
				solution.push_back(beverages[i]);
				expand(index + 1);
				solution.pop_back();
				usedBeverage[i] = 0;
			}
		}
		break;
	case 3:
		for (int i = 0; i < 5; i++) {
			if (usedBrand[i] == 1)
				continue;
			else {
				usedBrand[i] = 1;
				solution.push_back(cigars[i]);
				expand(index + 1);
				solution.pop_back();
				usedBrand[i] = 0;
			}
		}
		break;
	case 4: 
		for (int i = 0; i < 5; i++) {
			if (usedPet[i] == 1)
				continue;
			else {
				usedPet[i] = 1;
				solution.push_back(pets[i]);
				expand(index + 1);
				solution.pop_back();
				usedPet[i] = 0;
			}
		}
		break;
	default:
		break;
	}
}

void printNodeNumber() {
	cout << "the number of nodes : " << totalNode << endl;
}

void printSolution() {
	for (int i = 0; i < 25; i++) {
		if (i % 5 == 0)
			cout << "\nhouse " << i / 5 + 1 << ":" << endl;
		switch (i % 5)
		{
		case 0:
			cout << printStringColor(solution[i]) << " ";
			break;
		case 1:
			cout << printStringNationality(solution[i]) << " ";
			break;
		case 2:
			cout << printStringBeverage(solution[i]) << " ";
			break;
		case 3:
			cout << printStringCigar(solution[i]) << " ";
			break;
		case 4:
			cout << printStringPet(solution[i]) << " ";
			break;
		default:
			break;
		}
	}
	cout << endl;
}

const char* printStringColor(int colorNum) {
	switch (colorNum)
	{
	case BLUE:
		return "blue";
	case GREEN:
		return "green";
	case RED:
		return "red";
	case WHITE:
		return "white";
	case YELLOW:
		return "yellow";
	}
}

const char* printStringNationality(int nationNum) {
	switch (nationNum)
	{
	case BRIT:
		return "Brit";
	case DANE:
		return "Dane";
	case GERMAN:
		return "German";
	case NORWEIGIAN:
		return "Norweigian";
	case SWEDE:
		return "Swede";
	}
}

const char* printStringBeverage(int beverageNum) {
	switch (beverageNum)
	{
	case BEER:
		return "beer";
	case COFFEE:
		return "coffee";
	case MILK:
		return "milk";
	case TEA:
		return "tea";
	case WATER:
		return "water";
	}
}

const char* printStringCigar(int cigarNum) {
	switch (cigarNum)
	{
	case BLUE_MASTER:
		return "BlueMaster";
	case DUNHILL:
		return "Dunhill";
	case PALL_MALL:
		return "PallMall";
	case PRINCE:
		return "Prince";
	case BLEND:
		return "Blend";
	}
}

const char* printStringPet(int petNum) {
	switch (petNum)
	{
	case CAT:
		return "cat";
	case BIRD:
		return "bird";
	case DOG:
		return "dog";
	case ZEBRA:
		return "zebra";
	case HORSE:
		return "horse";
	}
}

int promising(int level) {
    int color = level - 5;
    int nationality = level - 4;
    int beverage = level - 3;
    int cigar = level - 2;
    int pet = level - 1;

    /* The Brit lives in a red house */
    if (solution[color] == RED)
        if (solution[nationality] != BRIT) {
            return -1;
        }
    if (solution[nationality] == BRIT)
        if (solution[color] != RED) {
            return -1;
        }
    /* The Swede keeps dogs as pets */
    if (solution[nationality] == SWEDE)
        if (solution[pet] != DOG) {
            return -1;
        }
    if (solution[pet] == DOG)
        if (solution[nationality] != SWEDE) {
            return -1;
        }
    /* The Dane drinkstea */
    if (solution[nationality] == DANE)
        if (solution[beverage] != TEA) {
            return -1;
        }
    if (solution[beverage] == TEA)
        if (solution[nationality] != DANE) {
            return -1;
        }
    /* The green house is on the left of the white house (next to it) */
    if (level > 9) {
        if (solution[color] == WHITE)
            if (solution[color - 5] != GREEN) {
                return -1;
            }
        if (solution[color - 5] == GREEN)
            if (solution[color] != WHITE) {
                return -1;
            }
    }
    /* The green house owner drinks coffee */
    if (solution[color] == GREEN)
        if (solution[beverage] != COFFEE) {
            return -1;
        }
    if (solution[beverage] == COFFEE)
        if (solution[color] != GREEN) {;
            return -1;
        }
    /* The person who smokes Pall Mall rears birds */
    if (solution[cigar] == PALL_MALL)
        if (solution[pet] != BIRD) {
            return -1;
        }
    if (solution[pet] == BIRD)
        if (solution[cigar] != PALL_MALL) {
            return -1;
        }
    /* The owner of the yellow house smokes Dunhill */
    if (solution[color] == YELLOW)
        if (solution[cigar] != DUNHILL) {
            return -1;
        }
    if (solution[cigar] == DUNHILL)
        if (solution[color] != YELLOW) {
            return -1;
        }
    /* The man living in the house right in the center drinks milk */
    if (level == 15) /** ��� �� :  MILK **/
        if (solution[beverage] != MILK) {
            return -1;
        }
    if (solution[beverage] == MILK)
        if (level != 15) {;
            return -1;
        }
    /* The Norwegian lives in the first(leftmost) house. */
    if (level == 5)
        if (solution[nationality] != NORWEIGIAN) {
            return -1;
        }
    if (solution[nationality] == NORWEIGIAN)
        if (level != 5) {
            return -1;
        }
    /* The man who smokes Blend lives next to the one who keeps cats */
    if (level > 9 && level < 21) {
        if (solution[cigar] == BLEND)
            if (solution[pet - 5] != CAT)
                return -1;
        if (solution[pet] == CAT)
            if (solution[level - 5] != BLEND)
                return -1;
    }
    /* The man who keeps horses lives next to the man who smokes
Dunhill. */
    if (level == 10)
        if (solution[pet] != HORSE) {
            return -1;
        }
    if (solution[pet] == HORSE)
        if (level != 10) {
            return -1;
        }
    /* The owner who smokes Blue Master drinks beer. */
    if (solution[cigar] == BLUE_MASTER)
        if (solution[beverage] != BEER) {
            return -1;
        }
    if (solution[beverage] == BEER)
        if (solution[cigar] != BLUE_MASTER) {
            return -1;
        }
    /* The German smokes Prince. */
    if (solution[nationality] == GERMAN)
        if (solution[cigar] != PRINCE) {
            return -1;
        }
    if (solution[cigar] == PRINCE)
        if (solution[nationality] != GERMAN) {
            return -1;
        }
    /* The Norwegian lives next to the blue house. */
    if (level == 10)
        if (solution[level - 5] != BLUE) {
            return -1;
        }
    if (solution[level - 5] == BLUE)
        if (level != 10) {
            return -1;
        }
    /* The man who smokes Blend has a neighbor who drinks water. */
    if (level > 9 && level < 21) {
        if (solution[cigar] == BLEND)
            if (solution[beverage - 5] != WATER)
                return -1;
        if (solution[beverage] == WATER)
            if (solution[cigar - 5] != BLEND)
                return -1;
    }
    
    return 1;
}

int main() {
	cout << "-----------------------------------------";
    expand(0);
	cout << endl;
    printNodeNumber();
	cout << "-----------------------------------------";
}