#pragma once
#ifndef __EINSTEIN_RIDDLE__
#define __EINSTEIN_RIDDLE__

#define BLUE (1)
#define GREEN (2)
#define RED (3)
#define WHITE (4)
#define YELLOW (5)

#define BRIT (6)
#define DANE (7)
#define GERMAN (8)
#define NORWEIGIAN (9)
#define SWEDE (10)

#define BEER (11)
#define COFFEE (12)
#define MILK (13)
#define TEA (14)
#define WATER (15)

#define BLUE_MASTER (16)
#define DUNHILL (17)
#define PALL_MALL (18)
#define PRINCE (19)
#define BLEND (20)

#define CAT (21)
#define BIRD (22)
#define DOG (23)
#define ZEBRA (24)
#define HORSE (25)

void expand(int index);
int promising(int level);
void printSolution();
void printNodeNumber();

const char* printStringColor(int colorNum);
const char* printStringNationality(int nationNum);
const char* printStringBeverage(int beverageNum);
const char* printStringCigar(int cigarNum);
const char* printStringPet(int petNum);

#endif