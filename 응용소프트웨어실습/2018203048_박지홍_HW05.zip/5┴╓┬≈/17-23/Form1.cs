﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _17_23
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void chkVisible_CheckedChanged(object sender, EventArgs e)
        {
            picProfile.Visible = !chkVisible.Checked;
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            picProfile.ImageLocation = txtUrl.Text;
        }

        private void rdoOption_CheckedChanged(object sender, EventArgs e)
        {
            var rdoOption = sender as RadioButton;

            if(null != rdoOption)
            {
                PictureBoxSizeMode SizeMode;

                if (rdoOption == rdoNormal)
                    SizeMode = PictureBoxSizeMode.Normal;
                else if (rdoOption == rdoStretchImage)
                    SizeMode = PictureBoxSizeMode.StretchImage;
                else if (rdoOption == rdoAutoSize)
                    SizeMode = PictureBoxSizeMode.AutoSize;
                else if (rdoOption == rdoCenterImage)
                    SizeMode = PictureBoxSizeMode.CenterImage;
                else
                    SizeMode = PictureBoxSizeMode.Zoom;

                picProfile.SizeMode = SizeMode;
            }
        }
    }
}
