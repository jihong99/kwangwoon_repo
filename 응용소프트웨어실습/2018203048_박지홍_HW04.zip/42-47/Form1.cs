﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _42_47
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public enum ControlParseCase
        {
            None,
            Name,
            Age,
            Gender
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            lvPeopleInfo.View = View.Details;

            lvPeopleInfo.Columns.Add("Name", "Name");
            lvPeopleInfo.Columns.Add("Age", "Age");
            lvPeopleInfo.Columns.Add("Gender", "Gender");
            lvPeopleInfo.Columns.Add("last", "last");

            lvPeopleInfo.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
            lvPeopleInfo.Columns.RemoveByKey("last");

            lvPeopleInfo.Columns[0].TextAlign = HorizontalAlignment.Left;
            lvPeopleInfo.Columns["Age"].TextAlign = HorizontalAlignment.Center;
            lvPeopleInfo.Columns[2].TextAlign = HorizontalAlignment.Right;

        }

        private void clearControls()
        {
            txtName.Clear();
            txtAge.Clear();
            cmbGender.SelectedItem = null;
        }

        private ControlParseCase GetControlParseCase()
        {
            if (string.Equals(txtName, string.Empty)) return ControlParseCase.Name;
            else if (string.Equals(txtName.Text, string.Empty)) return ControlParseCase.Age;
            else if (cmbGender.SelectedItem == null) return ControlParseCase.Gender;
            return ControlParseCase.None;
        }

        private Dictionary<string, string> GetControlParseDict()
        {
            return new Dictionary<string, string>()
            {
                { "Name",txtName.Text },
                {"Age",txtAge.Text },
                {"Gender",cmbGender.SelectedItem.ToString() }
            };
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (GetControlParseCase() != ControlParseCase.None) return;

            var lvwItem = new ListViewItem(new string[lvPeopleInfo.Columns.Count]);

            for (int i = 0; i < lvPeopleInfo.Columns.Count; i++)
                lvwItem.SubItems[i].Name = lvPeopleInfo.Columns[i].Name;

            var controlParseDict = GetControlParseDict();

            foreach (string item in controlParseDict.Keys)
                lvwItem.SubItems[item].Text = controlParseDict[item];

            lvPeopleInfo.Items.Add(lvwItem);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (lvPeopleInfo.FocusedItem == null) return;
            lvPeopleInfo.FocusedItem.Remove();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (GetControlParseCase() != ControlParseCase.None) return;

            var controlParseDict = GetControlParseDict();
            foreach(string item in controlParseDict.Keys)
            {
                var lvwItem = lvPeopleInfo.FocusedItem;
                lvwItem.SubItems[item].Text = controlParseDict[item];
            }
        }

        private void txtAge_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == Convert.ToChar(Keys.Back)) return;
            e.Handled = true;
        }
    }
}
