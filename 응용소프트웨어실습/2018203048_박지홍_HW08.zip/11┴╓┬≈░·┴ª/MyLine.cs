﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace _11주차과제
{
    internal class MyLine
    {
        private Point[] point = new Point[2];
        private int thick;
        private bool IsSolid;

        public MyLine()
        {
            point[0] = new Point();
            point[1] = new Point();
            thick = 1;
            IsSolid = true;
        }

        public void setPoint(Point start, Point finish, int thick, bool isSolid)
        {
            point[0] = start;
            point[1] = finish;
            this.thick = thick;
            this.IsSolid = isSolid;
        }

        public Point getPoint1()
        {
            return point[0];
        }

        public Point getPoint2()
        {
            return point[1];
        }

        public int getThick()
        {
            return thick;
        }

        public bool getSolid()
        {
            return IsSolid;
        }
    }
}
