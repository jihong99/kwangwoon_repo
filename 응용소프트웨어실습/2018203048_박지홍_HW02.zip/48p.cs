﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20220314
{
    internal class Class1
    {
        static void Main(string[] args)
        {
            int iNum1 = 3;
            int iNum2 = 3;

            Console.WriteLine("전위 연산자");
            Console.WriteLine("iNum1 = {0}, iNum2 = {1}", iNum1, iNum2);
            Console.WriteLine("++iNum1 = {0}, --iNum2 = {1}", ++iNum1, --iNum2);
            Console.WriteLine("iNum1 = {0}, iNum2 = {1}", iNum1, iNum2);

            iNum1 = 3;
            iNum2 = 3;
            Console.WriteLine("\n");

            Console.WriteLine("후위 연산자");
            Console.WriteLine("iNum1 = {0}, iNum2 = {1}", iNum1, iNum2);
            Console.WriteLine("iNum1++ = {0}, iNum2-- = {1}", iNum1++, iNum2--);
            Console.WriteLine("iNum1 = {0}, iNum2 = {1}", iNum1, iNum2);
        }
    }
}
