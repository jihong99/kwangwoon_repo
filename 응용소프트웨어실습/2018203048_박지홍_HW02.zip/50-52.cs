﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20220314
{
    public class Student
    {
        private int mINumber;
        private int mIScore;

        public Student(int iNumber, int iScore)
        {
            mINumber = iNumber;
            mIScore = iScore;
        }

        public int getNumber() { return mINumber; }
        public int getScore() { return mIScore; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            const int NUM_STUDENTS = 5;
            Array arrStudents = Array.CreateInstance(typeof(Student), NUM_STUDENTS);

            int iScoreSum = 0;
            double dScoreMean = 0.0;

            Console.WriteLine("<< {0}명의 학생의 점수를 입력하세요.", NUM_STUDENTS);
            for (int i = 0; i < NUM_STUDENTS; i++)
            {
                int iNumber = i + 1;
                string strScore = Console.ReadLine();
                int iScore = Convert.ToInt32(strScore);

                Student student = new Student(iNumber, iScore);
                arrStudents.SetValue(student, i);
            }

            for (int i = 0; i < arrStudents.Length; i++)
            {
                int iNumber = ((Student)arrStudents.GetValue(i)).getNumber();
                int iScore = ((Student)arrStudents.GetValue(i)).getScore();

                string strGrade = "F";
                if (iScore >= 90) { strGrade = "A"; }
                else if (iScore >= 80) { strGrade = "B"; }
                else if (iScore >= 70) { strGrade = "C"; }
                else if (iScore >= 60) { strGrade = "D"; }

                Console.WriteLine(">> {0} 번 학생의 점수: {1}, 등급 : {2}", iNumber, iScore, strGrade);

                iScoreSum += iScore;
            }

            dScoreMean = (double)iScoreSum / NUM_STUDENTS;
            Console.WriteLine("평균점수 : {0}", dScoreMean);
        }
    }
}
