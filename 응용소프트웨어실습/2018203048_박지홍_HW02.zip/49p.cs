﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20220314
{
    internal class Class1
    {
        static void Main(string[] args)
        {
            string strName;

            Console.Write("<< 이름을 입력하세요: ");
            strName = Console.ReadLine();
            Console.WriteLine(">> {0} 님, 안녕하세요!", strName);
        }

    }
}
