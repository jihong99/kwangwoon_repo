﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20220314
{
    internal class Class1
    {
        static void Main(string[] args)
        {
            string strText1 = " Hello ";
            string strText2 = " C# ";
            string strText3 = " World! ";
            string strText4 = strText1 + strText2 + strText3;

            Console.WriteLine("전체 문자열 : {0}", strText4);
            Console.WriteLine("전체 문자열의 길이 : {0}", strText4.Length);
            Console.WriteLine("문자열 시작과 끝의 공백 제거 : {0}", strText4.Trim());
            Console.WriteLine("C# 제거 : {0}", strText4.Remove(8, 2));
            Console.WriteLine("Hello를 안녕으로 변경 : {0}", strText4.Replace("Hello", "안녕"));
            Console.WriteLine("모두 대문자로 변경 : {0}", strText4.ToUpper());
            Console.WriteLine("모두 소문자로 변경 : {0}", strText4.ToLower());
        }
    }
}
