#include "fs.h"
#include "disk.h"
#include <stdio.h>

int main(){
	printf("Hello OS World\n");
	return 0;
}
