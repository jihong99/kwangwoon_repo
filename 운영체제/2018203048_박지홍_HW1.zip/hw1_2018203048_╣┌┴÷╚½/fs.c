#include <stdio.h>
#include <stdlib.h>
#include "disk.h"
#include "fs.h"
#include <string.h>

void FileSysInit(void)
{
    DevCreateDisk();
    char *block = (char*)malloc(BLOCK_SIZE);
    memset(block,0,BLOCK_SIZE);
    for(int i=0; i < 7; i++)
        DevWriteBlock(i, block);
    free(block);
}

void SetInodeBytemap(int inodeno)
{
    char *block = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(1, block);
    block[inodeno] = 1;
    DevWriteBlock(1, block);
}


void ResetInodeBytemap(int inodeno)
{
    char *block = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(1, block);
    block[inodeno] = 0;
    DevWriteBlock(1, block);
}


void SetBlockBytemap(int blkno)
{
    char *block = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(2, block);
    block[blkno] = 1;
    DevWriteBlock(2, block);
}


void ResetBlockBytemap(int blkno)
{
    char *block = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(2, block);
    block[blkno] = 0;
    DevWriteBlock(2, block);
}


void PutInode(int inodeno, Inode* pInode)
{
    char *block = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(4, block);
    memcpy(pInode, &block[inodeno], 32);
    DevWriteBlock(4, block);
}


void GetInode(int inodeno, Inode* pInode)
{
    char *block = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(3, block);
    memcpy(pInode, &block[inodeno], 32);
}


int GetFreeInodeNum(void)
{
    int result;
    char *block = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(1, block);
    for(int i=0; i<BLOCK_SIZE; i++){
        if(block[i] == 0){
            result = i;
            break;
        }
    }
    return result;
}


int GetFreeBlockNum(void)
{
    int result;
    char *block = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(2, block);
    for(int i =0; i<BLOCK_SIZE; i++){
        if(block[i] == 0){
            result = i;
            break;
        }
    }
    return result;
}

void PutIndirectBlockEntry(int blkno, int index, int number)
{
    char *block = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(blkno, block);
    int *iblock = (int*)block;
    iblock[index] = number;
    DevWriteBlock(blkno, block);
}

int GetIndirectBlockEntry(int blkno, int index)
{
    int number = 0;
    char *block = (char*)malloc(BLOCK_SIZE);
    int *iblock =(int*)block;
    DevReadBlock(blkno, block);
    number = iblock[index];
    return number;
}

void RemoveIndirectBlockEntry(int blkno, int index)
{
    char *block = (char*)malloc(BLOCK_SIZE);
    int *iblock = (int*)block;
    DevReadBlock(blkno, block);
    iblock[index] = INVALID_ENTRY;
    DevWriteBlock(blkno, block);
}

void PutDirEntry(int blkno, int index, DirEntry* pEntry)
{
    FileSysInit();
    char *block = (char*)malloc(BLOCK_SIZE);
    
    for(int i =7; i < BLOCK_SIZE; i++)
        DevWriteBlock(i, block);
    DirEntry *dblock = (DirEntry*)block;
    DevReadBlock(blkno, block);
    memcpy(&dblock[index], pEntry, 16);
    
    DevWriteBlock(blkno, block);
}

int GetDirEntry(int blkno, int index, DirEntry* pEntry)
{
    char *block = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(blkno, block);
    DirEntry *dblock = (DirEntry*)block;
    int *iblock = (int*)dblock;
    if(iblock[index] == INVALID_ENTRY){
        return -1;
    }
    else
        return 1;
}

void RemoveDirEntry(int blkno, int index)
{
    
    DirEntry drEtry;
    drEtry.inodeNum = INVALID_ENTRY;
}
