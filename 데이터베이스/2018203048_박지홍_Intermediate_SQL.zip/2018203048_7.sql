update instructor
set salary = 
( select count(ID) * 50000
from teaches
where instructor.ID = teaches.ID
group by ID);
update instructor
set salary = 30000
where salary is null;