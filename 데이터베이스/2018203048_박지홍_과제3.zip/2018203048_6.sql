select B.id, B.name, B.birth_year from people_likes as L left outer join people_main as A left outer join people_main as B
where L.id1 = A.id and L.id2 = B.id and A.birth_year > B.birth_year
group by B.name;