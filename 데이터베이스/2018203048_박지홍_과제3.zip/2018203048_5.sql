select name, occupation
from people_main
where ID =(select id1 from people_friends group by id1 having count(id1) > 3);