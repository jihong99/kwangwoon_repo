select title , count(M.MID) from actors as A, movies as M, actor_role as Ar
where A.NAME = 'Tilda Swinton' and A.AID = Ar.AID and M.MID = Ar.MID
group by title;