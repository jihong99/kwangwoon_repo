select count(*), name from people_likes as A, people_likes as B, people_main as M
where A.id1 = B.id2 and A.id2 = B.id1 and M.id = A.id1
group by name;