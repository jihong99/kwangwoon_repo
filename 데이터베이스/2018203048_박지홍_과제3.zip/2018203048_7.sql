select A.name, id1, id2, B.name from people_likes as L left outer join people_main as A left outer join people_main as B
where L.id1 = A.id and L.id2 = B.id and
(id1, id2) not in (select T.ID1,T.ID2 from people_likes as T left outer join people_friends as F
where T.ID1 = F.ID1 and T.ID2 = F.ID2)
order by A.name